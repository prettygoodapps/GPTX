# GPTX Contracts

This repo contains the ERC-20 smart contract for the GPTX token.