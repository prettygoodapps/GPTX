# GPTX Whitepaper

This repo contains the whitepaper and sustainability documentation for the GPTX project.

View online: [gptexchange.info](https://gptexchange.info)