# GPTX Green Ledger

Public transparency dashboard for carbon offset tracking and verification.