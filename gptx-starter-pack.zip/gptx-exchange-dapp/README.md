# GPTX Exchange DApp

Frontend client for interacting with the GPTX token swap and staking functionality.